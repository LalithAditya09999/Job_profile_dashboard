import { useState } from "react";
import Badge from "./Badge";
import styles from "./JobCard.module.css";

const JobCard = ({ job, applied, onApply }) => {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      className={`${styles.card} ${hovered ? styles.cardHovered : ""}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className={styles.header}>
        <div
          className={styles.logo}
          style={{ background: job.color + "18", color: job.color }}
        >
          {job.logo}
        </div>
        <div className={styles.headerText}>
          <h3 className={styles.title}>{job.title}</h3>
          <p className={styles.company}>{job.company}</p>
        </div>
        <Badge type={job.type} />
      </div>

      <div className={styles.meta}>
        <span className={styles.metaItem}>
          <span className={styles.metaIcon}>📍</span>
          {job.location}
        </span>
        <span className={styles.metaItem}>
          <span className={styles.metaIcon}>💰</span>
          {job.salary}
        </span>
        <span className={styles.metaItem}>
          <span className={styles.metaIcon}>🕒</span>
          {job.posted}
        </span>
      </div>

      <div className={styles.tags}>
        {job.tags.map((tag) => (
          <span key={tag} className={styles.tag}>
            {tag}
          </span>
        ))}
      </div>

      <button
        className={`${styles.applyBtn} ${applied ? styles.applied : ""}`}
        style={
          !applied
            ? { background: job.color, borderColor: job.color }
            : { color: job.color, borderColor: job.color + "55" }
        }
        onClick={() => onApply(job.id)}
      >
        {applied ? "✓ Applied" : "Apply Now"}
      </button>
    </div>
  );
};

export default JobCard;
