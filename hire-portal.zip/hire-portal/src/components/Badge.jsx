import { TYPE_COLORS } from "../data/jobs";

const Badge = ({ type }) => {
  const colors = TYPE_COLORS[type] || { bg: "#F3F4F6", text: "#6B7280" };
  return (
    <span
      style={{
        fontSize: 11,
        padding: "3px 10px",
        borderRadius: 999,
        background: colors.bg,
        color: colors.text,
        fontWeight: 600,
        whiteSpace: "nowrap",
        letterSpacing: "0.02em",
      }}
    >
      {type}
    </span>
  );
};

export default Badge;
