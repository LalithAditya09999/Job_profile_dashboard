import { useState } from "react";
import JOBS, { JOB_TYPES } from "../data/jobs";
import JobCard from "./JobCard";
import styles from "./JobBoard.module.css";

const JobBoard = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [applied, setApplied] = useState(new Set());

  const filtered = JOBS.filter((job) => {
    const q = search.toLowerCase();
    const matchSearch =
      !q ||
      job.title.toLowerCase().includes(q) ||
      job.company.toLowerCase().includes(q) ||
      job.location.toLowerCase().includes(q) ||
      job.tags.some((t) => t.toLowerCase().includes(q));
    const matchType = filter === "All" || job.type === filter;
    return matchSearch && matchType;
  });

  const handleApply = (id) => {
    setApplied((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  return (
    <div className={styles.container}>
      <div className={styles.pageHeader}>
        <div>
          <h1 className={styles.pageTitle}>Find Your Next Role</h1>
          <p className={styles.pageSubtitle}>
            {filtered.length} of {JOBS.length} positions available
          </p>
        </div>
        <div className={styles.appliedBadge}>
          {applied.size} Applied
        </div>
      </div>

      <div className={styles.controls}>
        <div className={styles.searchWrapper}>
          <span className={styles.searchIcon}>🔍</span>
          <input
            className={styles.searchInput}
            type="text"
            placeholder="Search jobs, companies, skills..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          {search && (
            <button
              className={styles.clearBtn}
              onClick={() => setSearch("")}
              aria-label="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        <div className={styles.filterTabs}>
          {JOB_TYPES.map((type) => (
            <button
              key={type}
              className={`${styles.filterTab} ${filter === type ? styles.activeTab : ""}`}
              onClick={() => setFilter(type)}
            >
              {type}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className={styles.emptyState}>
          <div className={styles.emptyIcon}>🔎</div>
          <p className={styles.emptyTitle}>No jobs found</p>
          <p className={styles.emptySubtitle}>
            Try different keywords or clear your filters
          </p>
          <button
            className={styles.resetBtn}
            onClick={() => { setSearch(""); setFilter("All"); }}
          >
            Reset filters
          </button>
        </div>
      ) : (
        <div className={styles.grid}>
          {filtered.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              applied={applied.has(job.id)}
              onApply={handleApply}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default JobBoard;
