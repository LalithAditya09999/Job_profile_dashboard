import { useState, useRef } from "react";
import styles from "./ProfileCompletion.module.css";

const FIELDS = [
  { key: "photo", label: "Profile Photo" },
  { key: "fullName", label: "Full Name" },
  { key: "email", label: "Email" },
  { key: "phone", label: "Phone" },
  { key: "skills", label: "Skills" },
  { key: "education", label: "Education" },
  { key: "resume", label: "Resume" },
];

const validate = (form, photo, resume) => {
  const errors = {};
  if (!form.fullName.trim()) errors.fullName = "Full name is required";
  else if (form.fullName.trim().length < 2) errors.fullName = "Name must be at least 2 characters";

  if (!form.email.trim()) errors.email = "Email is required";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errors.email = "Enter a valid email address";

  if (!form.phone.trim()) errors.phone = "Phone number is required";
  else if (!/^\d{10}$/.test(form.phone.replace(/\D/g, "")))
    errors.phone = "Enter a valid 10-digit phone number";

  if (!form.skills.trim()) errors.skills = "Add at least one skill";

  if (!form.education.trim()) errors.education = "Education details are required";

  return errors;
};

const ProfileCompletion = () => {
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    skills: "",
    education: "",
    bio: "",
  });
  const [errors, setErrors] = useState({});
  const [photo, setPhoto] = useState(null);
  const [resume, setResume] = useState(null);
  const [saved, setSaved] = useState(false);
  const [touched, setTouched] = useState({});

  const photoRef = useRef();
  const resumeRef = useRef();

  const isFilled = {
    photo: !!photo,
    fullName: form.fullName.trim().length >= 2,
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email),
    phone: /^\d{10}$/.test(form.phone.replace(/\D/g, "")),
    skills: form.skills.trim().length > 0,
    education: form.education.trim().length > 0,
    resume: !!resume,
  };

  const filledCount = Object.values(isFilled).filter(Boolean).length;
  const pct = Math.round((filledCount / FIELDS.length) * 100);

  const progressColor =
    pct < 40 ? "#EF4444" : pct < 70 ? "#F59E0B" : "#10B981";

  const setField = (key, value) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    if (touched[key]) {
      const newErrors = validate({ ...form, [key]: value }, photo, resume);
      setErrors((prev) => ({ ...prev, [key]: newErrors[key] }));
    }
  };

  const handleBlur = (key) => {
    setTouched((prev) => ({ ...prev, [key]: true }));
    const errs = validate(form, photo, resume);
    setErrors((prev) => ({ ...prev, [key]: errs[key] }));
  };

  const handleSubmit = () => {
    const allTouched = Object.fromEntries(
      ["fullName", "email", "phone", "skills", "education"].map((k) => [k, true])
    );
    setTouched(allTouched);
    const errs = validate(form, photo, resume);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => setPhoto(ev.target.result);
    reader.readAsDataURL(file);
  };

  return (
    <div className={styles.container}>
      <div className={styles.pageHeader}>
        <div>
          <h1 className={styles.pageTitle}>Complete Your Profile</h1>
          <p className={styles.pageSubtitle}>
            A complete profile gets 3× more recruiter views
          </p>
        </div>
      </div>

      {/* Progress Card */}
      <div className={styles.progressCard}>
        <div className={styles.progressHeader}>
          <span className={styles.progressLabel}>Profile Strength</span>
          <span className={styles.progressPct} style={{ color: progressColor }}>
            {pct}%
          </span>
        </div>
        <div className={styles.progressTrack}>
          <div
            className={styles.progressBar}
            style={{ width: `${pct}%`, background: progressColor }}
          />
        </div>
        <div className={styles.fieldChips}>
          {FIELDS.map((f) => (
            <span
              key={f.key}
              className={`${styles.chip} ${isFilled[f.key] ? styles.chipDone : ""}`}
            >
              {isFilled[f.key] ? "✓ " : ""}
              {f.label}
            </span>
          ))}
        </div>
      </div>

      {/* Form Card */}
      <div className={styles.formCard}>
        {/* Photo */}
        <div className={styles.photoSection}>
          <div
            className={styles.photoCircle}
            onClick={() => photoRef.current.click()}
            role="button"
            tabIndex={0}
            aria-label="Upload profile photo"
            onKeyDown={(e) => e.key === "Enter" && photoRef.current.click()}
          >
            {photo ? (
              <img src={photo} alt="Profile" className={styles.photoImg} />
            ) : (
              <span className={styles.photoPlaceholder}>👤</span>
            )}
            <div className={styles.photoOverlay}>📷</div>
          </div>
          <input
            type="file"
            accept="image/*"
            ref={photoRef}
            style={{ display: "none" }}
            onChange={handlePhotoChange}
          />
          <div>
            <p className={styles.photoName}>
              {form.fullName || "Your Name"}
            </p>
            <p className={styles.photoHint}>Click photo to upload</p>
          </div>
        </div>

        <div className={styles.divider} />

        {/* Form Fields */}
        <div className={styles.grid}>
          <div className={styles.fieldGroup}>
            <label className={styles.label} htmlFor="fullName">
              Full Name <span className={styles.required}>*</span>
            </label>
            <input
              id="fullName"
              className={`${styles.input} ${errors.fullName ? styles.inputError : isFilled.fullName ? styles.inputSuccess : ""}`}
              type="text"
              placeholder="e.g. Lalith Kumar"
              value={form.fullName}
              onChange={(e) => setField("fullName", e.target.value)}
              onBlur={() => handleBlur("fullName")}
            />
            {errors.fullName && <p className={styles.err}>{errors.fullName}</p>}
          </div>

          <div className={styles.fieldGroup}>
            <label className={styles.label} htmlFor="email">
              Email Address <span className={styles.required}>*</span>
            </label>
            <input
              id="email"
              className={`${styles.input} ${errors.email ? styles.inputError : isFilled.email ? styles.inputSuccess : ""}`}
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => setField("email", e.target.value)}
              onBlur={() => handleBlur("email")}
            />
            {errors.email && <p className={styles.err}>{errors.email}</p>}
          </div>

          <div className={styles.fieldGroup}>
            <label className={styles.label} htmlFor="phone">
              Phone Number <span className={styles.required}>*</span>
            </label>
            <input
              id="phone"
              className={`${styles.input} ${errors.phone ? styles.inputError : isFilled.phone ? styles.inputSuccess : ""}`}
              type="tel"
              placeholder="10-digit number"
              value={form.phone}
              onChange={(e) => setField("phone", e.target.value)}
              onBlur={() => handleBlur("phone")}
            />
            {errors.phone && <p className={styles.err}>{errors.phone}</p>}
          </div>

          <div className={styles.fieldGroup}>
            <label className={styles.label} htmlFor="skills">
              Skills <span className={styles.required}>*</span>
            </label>
            <input
              id="skills"
              className={`${styles.input} ${errors.skills ? styles.inputError : isFilled.skills ? styles.inputSuccess : ""}`}
              type="text"
              placeholder="React, Python, SQL (comma-separated)"
              value={form.skills}
              onChange={(e) => setField("skills", e.target.value)}
              onBlur={() => handleBlur("skills")}
            />
            {errors.skills && <p className={styles.err}>{errors.skills}</p>}
            {form.skills && (
              <div className={styles.skillPills}>
                {form.skills.split(",").filter((s) => s.trim()).map((skill, i) => (
                  <span key={i} className={styles.skillPill}>{skill.trim()}</span>
                ))}
              </div>
            )}
          </div>

          <div className={`${styles.fieldGroup} ${styles.fullWidth}`}>
            <label className={styles.label} htmlFor="education">
              Education Details <span className={styles.required}>*</span>
            </label>
            <textarea
              id="education"
              className={`${styles.input} ${styles.textarea} ${errors.education ? styles.inputError : isFilled.education ? styles.inputSuccess : ""}`}
              placeholder="B.Tech in CSE, Anna University, 2022–2026"
              value={form.education}
              onChange={(e) => setField("education", e.target.value)}
              onBlur={() => handleBlur("education")}
              rows={3}
            />
            {errors.education && <p className={styles.err}>{errors.education}</p>}
          </div>

          <div className={`${styles.fieldGroup} ${styles.fullWidth}`}>
            <label className={styles.label} htmlFor="bio">
              Short Bio <span className={styles.optional}>(optional)</span>
            </label>
            <textarea
              id="bio"
              className={styles.input + " " + styles.textarea}
              placeholder="A brief professional summary..."
              value={form.bio}
              onChange={(e) => setField("bio", e.target.value)}
              rows={2}
            />
          </div>

          {/* Resume Upload */}
          <div className={`${styles.fieldGroup} ${styles.fullWidth}`}>
            <label className={styles.label}>Resume</label>
            <div
              className={`${styles.resumeZone} ${resume ? styles.resumeUploaded : ""}`}
              onClick={() => resumeRef.current.click()}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && resumeRef.current.click()}
            >
              <span className={styles.resumeIcon}>{resume ? "📄" : "⬆️"}</span>
              {resume ? (
                <div>
                  <p className={styles.resumeName}>{resume.name}</p>
                  <p className={styles.resumeSize}>
                    {(resume.size / 1024).toFixed(1)} KB · Click to replace
                  </p>
                </div>
              ) : (
                <div>
                  <p className={styles.resumePrompt}>
                    Click to upload your resume
                  </p>
                  <p className={styles.resumeTypes}>PDF, DOC, DOCX — max 5MB</p>
                </div>
              )}
            </div>
            <input
              type="file"
              accept=".pdf,.doc,.docx"
              ref={resumeRef}
              style={{ display: "none" }}
              onChange={(e) => e.target.files[0] && setResume(e.target.files[0])}
            />
          </div>
        </div>

        <div className={styles.formFooter}>
          {saved && (
            <div className={styles.savedBanner}>
              ✓ Profile saved successfully!
            </div>
          )}
          <button className={styles.submitBtn} onClick={handleSubmit}>
            {saved ? "✓ Saved!" : "Save Profile"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileCompletion;
